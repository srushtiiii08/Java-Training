package com.techlabs.model;

import java.sql.Timestamp;

public class Result {
	private int id;
    private int userId;
    private int score;
    private Timestamp takenOn;
    
    
	public int getId() {
		return id;
	}
	public int getUserId() {
		return userId;
	}
	public int getScore() {
		return score;
	}
	public Timestamp getTakenOn() {
		return takenOn;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public void setTakenOn(Timestamp takenOn) {
		this.takenOn = takenOn;
	}
    
    
}
