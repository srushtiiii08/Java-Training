package com.techlas.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techlabs.model.Question;
import com.techlabs.utils.DBConnection;

@WebServlet("/result")
public class ResultServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {

        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("userId") == null) {
            resp.sendRedirect("login.html");
            return;
        }

        int userId = (int) session.getAttribute("userId");
        Map<Integer, Character> answers = (Map<Integer, Character>) session.getAttribute("answers");
        List<Question> quizQuestions = (List<Question>) session.getAttribute("quizQuestions");

        if (answers == null || quizQuestions == null) {
            resp.sendRedirect("error.html");
            return;
        }

        try (Connection con = DBConnection.getConnection()) {

            int score = 0;
            int total = answers.size();

            // Build HTML
            resp.setContentType("text/html");
            StringBuilder html = new StringBuilder();
            html.append("<!DOCTYPE html><html><head><meta charset='UTF-8'><title>Quiz Result</title>")
                .append("<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css' rel='stylesheet'>")
                .append("<style>")
                .append("body{background:lavender; font-family: 'Segoe UI', sans-serif;}")
                .append(".card{background:white; border-radius:15px; padding:20px; box-shadow:0 5px 15px rgba(0,0,0,0.15);}")
                .append(".btn-primary{background:#7B68EE; border:none; border-radius:25px; font-weight:bold; transition:all 0.3s ease;}")
                .append(".btn-primary:hover{background:#6A5ACD; transform:scale(1.05);}")
                .append(".btn-logout{background:linear-gradient(135deg,#ff4e50,#f9d423); border:none; color:white; border-radius:25px; font-weight:bold; transition:all 0.3s;}")
                .append(".btn-logout:hover{background:linear-gradient(135deg,#e34447,#f7c933); transform:scale(1.07);}")
                .append("</style></head><body>");

            // Navbar
            html.append("<div class='container mt-3 d-flex justify-content-between align-items-center'>")
                .append("<h4>Well done, ").append(session.getAttribute("username")).append("</h4>")
                .append("<form method='post' action='logout' onsubmit=\"return confirm('Are you sure you want to logout?');\">")
                .append("<button class='btn btn-logout' type='submit'>Logout</button>")
                .append("</form></div><hr>");

            html.append("<div class='container' style='max-width:900px;'>")
                .append("<div class='card'>")
                .append("<h3 class='mb-3'>Your Score: ");

            // Calculate and build answer table
            StringBuilder table = new StringBuilder();
            table.append("<table class='table table-bordered mt-4'>")
                 .append("<thead class='table-light'><tr>")
                 .append("<th>#</th><th>Question</th><th>Your Answer</th><th>Correct Answer</th><th>Result</th>")
                 .append("</tr></thead><tbody>");

            int qIndex = 1;
            for (Question q : quizQuestions) {
                char userAns = answers.getOrDefault(q.getId(), ' ');
                char correctAns = q.getCorrectOption();
                boolean isCorrect = (userAns == correctAns);

                if (isCorrect) score++;

                // Full option text for better clarity
                String userAnsText = getOptionText(q, userAns);
                String correctAnsText = getOptionText(q, correctAns);

                table.append("<tr>")
                     .append("<td>").append(qIndex++).append("</td>")
                     .append("<td>").append(q.getQuestionText()).append("</td>")
                     .append("<td>").append(userAns == ' ' ? "-" : userAns + ". " + userAnsText).append("</td>")
                     .append("<td>").append(correctAns).append(". ").append(correctAnsText).append("</td>")
                     .append("<td>").append(isCorrect
                                 ? "<span class='badge bg-success'>Correct</span>"
                                 : "<span class='badge bg-danger'>Incorrect</span>")
                     .append("</td>")
                     .append("</tr>");
            }
            table.append("</tbody></table>");

            html.append(score).append(" / ").append(total).append("</h3>");
            html.append(table);
            html.append("<a href='quiz?question=1' class='btn btn-primary mt-3'>Retake Quiz</a>");
            html.append("<a href='leaderboard' target='_blank' class='btn btn-success ms-3 mt-4'>View Leaderboard</a>");
            html.append("</div></div></body></html>");

            resp.getWriter().println(html.toString());

            // Save result to DB AFTER output
            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO results(user_id, score) VALUES(?, ?)");
            ps.setInt(1, userId);
            ps.setInt(2, score);
            ps.executeUpdate();

            // Clear session quiz data
            session.removeAttribute("answers");
            session.removeAttribute("quizQuestions");

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            resp.sendRedirect("error.html");
        }
    }

    // Helper to map answer letter to the full text from the Question object
    private String getOptionText(Question q, char option) {
        if (option == 'A') return q.getOptionA();
        if (option == 'B') return q.getOptionB();
        if (option == 'C') return q.getOptionC();
        if (option == 'D') return q.getOptionD();
        return "";
    }
}
