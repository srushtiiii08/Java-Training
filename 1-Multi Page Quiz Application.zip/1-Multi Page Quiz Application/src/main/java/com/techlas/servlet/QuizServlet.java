package com.techlas.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techlabs.model.Question;
import com.techlabs.utils.DBConnection;

@WebServlet("/quiz")
public class QuizServlet extends HttpServlet {

    private List<Question> fetchAllQuestions() throws SQLException, ClassNotFoundException {
        List<Question> questions = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM questions")) {
            while (rs.next()) {
                Question q = new Question();
                q.setId(rs.getInt("id"));
                q.setQuestionText(rs.getString("question_text"));
                q.setOptionA(rs.getString("option_a"));
                q.setOptionB(rs.getString("option_b"));
                q.setOptionC(rs.getString("option_c"));
                q.setOptionD(rs.getString("option_d"));
                q.setCorrectOption(rs.getString("correct_option").charAt(0));
                questions.add(q);
            }
        }
        return questions;
    }

    private List<Question> selectRandomQuestions(List<Question> allQuestions, int count) {
        Collections.shuffle(allQuestions);
        return allQuestions.subList(0, Math.min(count, allQuestions.size()));
    }

    private String createOption(String option, String text) {
        return "<div class='form-check mb-2'>" +
                "<input class='form-check-input' type='radio' id='option" + option + "' name='answer' value='" + option + "' required>" +
                "<label class='form-check-label' for='option" + option + "'>" + option + ". " + text + "</label></div>";
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("userId") == null) {
            resp.sendRedirect("login.html");
            return;
        }

        int questionNum;
        try {
            questionNum = Integer.parseInt(req.getParameter("question"));
        } catch (NumberFormatException e) {
            questionNum = 1;	  //if missing or invalid, defaults to 1.
        }

        List<Question> sessionQuestions = (List<Question>) session.getAttribute("quizQuestions");
        if (sessionQuestions == null) {
            try {
                sessionQuestions = selectRandomQuestions(fetchAllQuestions(), 3);
                session.setAttribute("quizQuestions", sessionQuestions);
            } catch (SQLException | ClassNotFoundException e) {
                e.printStackTrace();
                resp.sendRedirect("error.html");
                return;
            }
        }

        if (questionNum < 1 || questionNum > sessionQuestions.size()) {
            resp.sendRedirect("quiz?question=1");
            return;
        }

        // ===== TIME REMAINING CALC =====
        long startTime = (long) session.getAttribute("quizStartTime");
        long expiryTime = startTime + (3 * 60 * 1000);
        long remainingSeconds = (expiryTime - System.currentTimeMillis()) / 1000;

        if (remainingSeconds <= 0) {
            resp.sendRedirect("result"); // time's up
            return;
        }

        Question currentQ = sessionQuestions.get(questionNum - 1);

        resp.setContentType("text/html");
        StringBuilder html = new StringBuilder();

        html.append("<!DOCTYPE html><html><head><meta charset='UTF-8'><title>Quiz</title>")
            .append("<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css' rel='stylesheet'>")
            .append("<style>")
            .append("body{background:lavender;} .card{background:white; border-radius:15px; padding:25px; box-shadow:0 5px 15px rgba(0,0,0,0.15);} ")
            .append(".btn-primary{background:#7B68EE; border:none; border-radius:25px; padding:8px 20px; font-weight:bold; transition:all 0.3s ease;} ")
            .append(".btn-primary:hover{background:#6A5ACD; transform:scale(1.05);} ")
            .append(".btn-secondary{border-radius:25px; padding:8px 20px;} ")
            .append(".badge{cursor:pointer;} ")
            .append("</style></head><body>");

        // ===== TIME PANEL =====
        html.append("<div style='position:fixed;top:10px;right:20px;background:white;padding:8px;border-radius:8px;box-shadow:0 2px 6px rgba(0,0,0,0.2);'>")
            .append("Time Remaining: <span id='timeRem'>").append(remainingSeconds).append("</span> sec</div>");

        // Navbar
        html.append("<div class='container mt-3 d-flex justify-content-between'>")
            .append("<h4>Hello, ").append(session.getAttribute("username")).append("</h4>")
            .append("<form method='post' action='logout'><button class='btn btn-danger btn-sm'>Logout</button></form>")
            .append("</div><hr>");

        // Question card
        html.append("<div class='container' style='max-width:650px;'><div class='card'>")
            .append("<h5>Question ").append(questionNum).append(" of ").append(sessionQuestions.size()).append("</h5>")
            .append("<p>").append(currentQ.getQuestionText()).append("</p>")
            .append("<form method='post' action='quiz'>")
            .append(createOption("A", currentQ.getOptionA()))
            .append(createOption("B", currentQ.getOptionB()))
            .append(createOption("C", currentQ.getOptionC()))
            .append(createOption("D", currentQ.getOptionD()))
            .append("<input type='hidden' name='questionNumber' value='").append(questionNum).append("'>");

        // Back button
        if (questionNum > 1) {
            html.append("<a href='quiz?question=").append(questionNum - 1).append("' class='btn btn-secondary me-2'>Back</a>");
        }

        // Next/Finish button
        String btnText = (questionNum == sessionQuestions.size()) ? "Finish" : "Next";
        html.append("<button class='btn btn-primary' type='submit'>").append(btnText).append("</button>")
            .append("</form>");

        // Question number navigation badges
        html.append("<div class='mt-3'>");
        for (int i = 1; i <= sessionQuestions.size(); i++) {
            if (i == questionNum) {
                html.append("<span class='badge bg-primary me-1'>").append(i).append("</span>");
            } else {
                html.append("<a href='quiz?question=").append(i)
                        .append("' class='badge bg-secondary me-1'>").append(i).append("</a>");
            }
        }
        html.append("</div>"); // end badge list

        html.append("</div></div>"); // end card+container

        // JavaScript countdown
        html.append("<script>let sec=").append(remainingSeconds)
            .append(";let timer=setInterval(()=>{sec--;document.getElementById('timeRem').textContent=sec;if(sec<=0){clearInterval(timer);window.location='result';}},1000);</script>");

        html.append("</body></html>");

        resp.getWriter().println(html.toString());
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("userId") == null) {
            resp.sendRedirect("login.html");
            return;
        }

        int questionNumber = Integer.parseInt(req.getParameter("questionNumber"));
        String answer = req.getParameter("answer");

        Map<Integer, Character> userAnswers = (Map<Integer, Character>) session.getAttribute("answers");
        if (userAnswers == null) {
            userAnswers = new HashMap<>();
        }

        List<Question> quizQuestions = (List<Question>) session.getAttribute("quizQuestions");
        userAnswers.put(quizQuestions.get(questionNumber - 1).getId(), answer.charAt(0));
        session.setAttribute("answers", userAnswers);

        if (questionNumber < quizQuestions.size()) {
            resp.sendRedirect("quiz?question=" + (questionNumber + 1));
        } else {
            resp.sendRedirect("result");
        }
    }
}
