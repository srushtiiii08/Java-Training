package com.techlas.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techlabs.utils.DBConnection;

@WebServlet("/leaderboard")
public class LeaderBoardServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("userId") == null) {
            resp.sendRedirect("login.html");
            return;
        }

        resp.setContentType("text/html");
        StringBuilder html = new StringBuilder();

        html.append("<!DOCTYPE html><html><head><meta charset='UTF-8'><title>Leaderboard</title>")
            .append("<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css' rel='stylesheet'>")
            .append("<style>")
            .append("body{background:lavender; font-family:'Segoe UI',sans-serif;} ")
            .append(".container{max-width:900px; margin-top:40px;} ")
            .append(".card{background:white; border-radius:15px; padding:20px; box-shadow:0 5px 15px rgba(0,0,0,0.15);} ")
            .append("table{width:100%;} ")
            .append(".btn-logout{background:linear-gradient(135deg,#ff4e50,#f9d423); border:none; color:white; border-radius:25px; padding:6px 18px; font-weight:bold; transition:all 0.3s;} ")
            .append(".btn-logout:hover{background:linear-gradient(135deg,#e34447,#f7c933); transform:scale(1.07);} ")
            .append("</style></head><body>");

        html.append("<div class='container d-flex justify-content-between align-items-center mb-3'>")
            .append("<h4>Leaderboard</h4>")
            .append("<div>")
            .append("<span>Logged in as: ").append(session.getAttribute("username")).append("</span> &nbsp;&nbsp;")

            .append("<form method='post' action='logout' style='display:inline;' onsubmit=\"return confirm('Are you sure you want to logout?');\">")
            .append("<button class='btn btn-logout' type='submit'>Logout</button></form>")
            .append("</div>")
            .append("</div>");

        html.append("<div class='container'><div class='card'>");
        html.append("<table class='table table-striped table-bordered'>");
        html.append("<thead class='table-primary'><tr><th>Rank</th><th>Username</th><th>Score</th><th>Attempted On</th></tr></thead><tbody>");

        try (Connection con = DBConnection.getConnection()) {
            // Query results joined with users
            String query = "SELECT u.username, r.score, r.taken_at FROM results r JOIN users u ON r.user_id = u.id ORDER BY r.score DESC, r.taken_at DESC";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(query);

            int rank = 1;
            while (rs.next()) {
                String uname = rs.getString("username");
                int score = rs.getInt("score");
                Timestamp ts = rs.getTimestamp("taken_at");

                html.append("<tr>")
                    .append("<td>").append(rank++).append("</td>")
                    .append("<td>").append(uname).append("</td>")
                    .append("<td>").append(score).append("</td>")
                    .append("<td>").append(ts.toString()).append("</td>")
                    .append("</tr>");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            html.append("<tr><td colspan='4'>Error loading leaderboard data.</td></tr>");
        } catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

        html.append("</tbody></table>");
        html.append("</div></div>");
        html.append("</body></html>");

        resp.getWriter().println(html.toString());
    }
}
