package com.techlas.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.techlabs.utils.DBConnection;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.sendRedirect("register.html");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String username = request.getParameter("username") != null ? request.getParameter("username").trim() : "";
        String password = request.getParameter("password") != null ? request.getParameter("password").trim() : "";
        String email = request.getParameter("email") != null ? request.getParameter("email").trim() : "";

        if (username.isEmpty() || password.isEmpty() || email.isEmpty()) {
            response.sendRedirect("register-missing.html");
            return;
        }

        try (Connection con = DBConnection.getConnection()) {
            // if 
            PreparedStatement ps = con.prepareStatement("SELECT id FROM users WHERE username = ?");
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                response.sendRedirect("register-error.html");
                return;
            }


            ps = con.prepareStatement("INSERT INTO users(username, password, email) VALUES(?,?,?)");
            ps.setString(1, username);
            ps.setString(2, password); 
            ps.setString(3, email);
            ps.executeUpdate();


            response.sendRedirect("login.html?msg=Registration+successful,+please+login");

        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("error.html");
        } catch (ClassNotFoundException e1) {
            e1.printStackTrace();
            response.sendRedirect("error.html");
        }
    }
}
