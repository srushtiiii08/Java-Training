use quizapp;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(50) NOT NULL, 
    email VARCHAR(100) NOT NULL
);

CREATE TABLE questions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    question_text VARCHAR(255) NOT NULL,
    option_a VARCHAR(100) NOT NULL,
    option_b VARCHAR(100) NOT NULL,
    option_c VARCHAR(100) NOT NULL,
    option_d VARCHAR(100) NOT NULL,
    correct_option CHAR(1) NOT NULL
);

CREATE TABLE results (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    score INT NOT NULL,
    taken_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

INSERT INTO questions (question_text, option_a, option_b, option_c, option_d, correct_option) VALUES
('Which language is used for Android development?', 'Java', 'Python', 'Swift', 'C#', 'A'),
('What is the capital of France?', 'Berlin', 'Madrid', 'Paris', 'Rome', 'C'),
('Which company developed Java?', 'Microsoft', 'Sun Microsystems', 'Apple', 'Google', 'B');

insert into questions (question_text, option_a, option_b, option_c, option_d, correct_option) VALUES 
('Which keyword is used to inherit a class in Java?', 'implement', 'extends', 'inherits', 'super', 'B'),
('Which method is the entry point of a Java program?', 'start()', 'main()', 'run()', 'init()', 'B'),
('How do you declare an array in Java?', 'int arr[];', 'int arr();', 'int[] arr;', 'Both A and C', 'D');


delete from results where id between 14 and 24;
delete from results where id between 12 and 32;